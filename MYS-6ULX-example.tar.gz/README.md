# MYiR samples


These samples program running on some MYiR develop board.Here is support list:

* MYD-JA5D4X
* MYD-JA5D3X

## Compile

Before you compile this project, you must setting your environment.

    export PATH=$PATH:${ARM_TOOLCHAIN_BIN_PATH}
    export CC=arm-linux-gnueabihf-gcc
    export CROSS_COMPILE=arm-linux-gnueabihf-
